const isValidgroupID = (groupIDList) => groupIDList.length > 1;

module.exports = {
  isValidgroupID
};
